"""图表代码执行工具。

用途：
1. 提供给大模型执行短时图表处理代码。
2. 返回标准输出、错误输出、执行结果与图表文件列表。

约定：
- 用户代码可通过 `_result` 返回结构化结果。
- 用户代码可通过 `_chart_files` 返回生成文件路径列表。
- 推荐用于图表专项处理任务，支持中等复杂度绘图脚本。
"""

from __future__ import annotations

import contextlib
import io
import os
import traceback
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple


def _safe_import(module_name: str):
    """尝试导入模块，失败时返回 None，避免工具整体失败。"""
    try:
        module = __import__(module_name)
        return module
    except Exception:
        return None


def _detect_chart_libraries() -> Dict[str, str]:
    """检测常见图表库可用性并返回版本摘要。"""
    summary: Dict[str, str] = {}
    for name in ("numpy", "pandas", "matplotlib", "seaborn", "plotly"):
        module = _safe_import(name)
        if module is None:
            summary[name] = "missing"
            continue
        summary[name] = str(getattr(module, "__version__", "unknown"))
    return summary


@dataclass
class _FontCandidate:
    """候选字体信息。"""

    path: str
    source_order: int
    preferred_hit: bool
    supports_cjk: bool


def _font_supports_chinese(font_path: str) -> bool:
    """检测字体是否包含常见中文字符。"""
    try:
        from fontTools.ttLib import TTCollection
        from fontTools.ttLib import TTFont
    except Exception:
        return False

    required_chars = ("中", "文", "图", "表", "月")
    required_codes = {ord(ch) for ch in required_chars}

    def _font_has_required_codes(font_obj: Any) -> bool:
        cmap_table = getattr(font_obj, "cmap", None)
        if cmap_table is None:
            return False
        covered = set()
        for table in getattr(cmap_table, "tables", []):
            cmap = getattr(table, "cmap", None) or {}
            covered.update(cmap.keys())
            if required_codes.issubset(covered):
                return True
        return False

    try:
        lower_name = os.path.basename(font_path).lower()
        if lower_name.endswith(".ttc"):
            collection = TTCollection(font_path, lazy=True)
            try:
                for font_obj in collection.fonts:
                    if _font_has_required_codes(font_obj):
                        return True
            finally:
                try:
                    collection.close()
                except Exception:
                    pass
            return False

        font_obj = TTFont(font_path, lazy=True)
        try:
            return _font_has_required_codes(font_obj)
        finally:
            try:
                font_obj.close()
            except Exception:
                pass
    except Exception:
        return False


def _collect_chinese_font_candidates() -> List[_FontCandidate]:
    """收集可用于 matplotlib 的中文字体候选。"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    plugin_root = os.path.dirname(script_dir)
    # 重要：
    # Android 上对 /system/fonts 全量扫描并 addfont，容易在部分机型触发 ft2font 原生崩溃。
    # 这里不再遍历系统字体目录，只使用：
    # 1) 插件内字体目录（推荐）
    # 2) 少量系统白名单字体路径（存在才加入）
    candidate_dirs = [
        os.path.join(plugin_root, "assets", "fonts"),
        os.path.join(plugin_root, "libs", "fonts"),
    ]
    system_font_whitelist = [
        "/system/fonts/NotoSansCJK-Regular.ttc",
        "/system/fonts/NotoSansSC-Regular.otf",
        "/system/fonts/SourceHanSansCN-Regular.otf",
        "/system/fonts/DroidSansFallback.ttf",
    ]
    preferred_names = (
        "harmony",
        "hmos",
        "NotoSansCJK",
        "NotoSansSC",
        "SourceHanSans",
        "DroidSansFallback",
        "MiSans",
        "PingFang",
        "simhei",
        "msyh",
    )
    result: List[_FontCandidate] = []
    seen = set()
    for source_order, folder in enumerate(candidate_dirs):
        if not os.path.isdir(folder):
            continue
        for root, _, files in os.walk(folder):
            for name in files:
                lower = name.lower()
                if not (
                    lower.endswith(".ttf")
                    or lower.endswith(".ttc")
                    or lower.endswith(".otf")
                ):
                    continue
                full_path = os.path.abspath(os.path.join(root, name))
                if full_path in seen:
                    continue
                seen.add(full_path)
                preferred_hit = any(
                    keyword.lower() in os.path.basename(full_path).lower()
                    for keyword in preferred_names
                )
                result.append(
                    _FontCandidate(
                        path=full_path,
                        source_order=source_order,
                        preferred_hit=preferred_hit,
                        supports_cjk=_font_supports_chinese(full_path),
                    )
                )

    # 仅追加系统白名单字体，避免全量扫描系统目录导致 native 崩溃。
    for full_path in system_font_whitelist:
        normalized = os.path.abspath(full_path)
        if normalized in seen or not os.path.isfile(normalized):
            continue
        seen.add(normalized)
        preferred_hit = any(
            keyword.lower() in os.path.basename(normalized).lower()
            for keyword in preferred_names
        )
        result.append(
            _FontCandidate(
                path=normalized,
                source_order=99,
                preferred_hit=preferred_hit,
                supports_cjk=_font_supports_chinese(normalized),
            )
        )

    # 排序策略：
    # 1) 先保证“实际支持中文字形”；
    # 2) 再按命名关键词倾向中文字体；
    # 3) 再按目录优先级（插件内字体 > 系统字体）。
    result.sort(
        key=lambda item: (
            0 if item.supports_cjk else 1,
            0 if item.preferred_hit else 1,
            item.source_order,
            os.path.basename(item.path).lower(),
        )
    )
    return result


def _setup_matplotlib_chinese() -> str:
    """配置 matplotlib 中文字体，返回配置摘要。"""
    matplotlib = _safe_import("matplotlib")
    if matplotlib is None:
        return "matplotlib: missing"

    try:
        matplotlib.use("Agg")
    except Exception:
        pass

    font_manager = None
    try:
        font_manager = __import__("matplotlib.font_manager", fromlist=["font_manager"])
    except Exception:
        font_manager = None

    resolved_names: List[str] = []
    selected_font_name = ""
    selected_font_path = ""
    scanned_font_count = 0
    cjk_ready_count = 0
    for candidate in _collect_chinese_font_candidates():
        font_path = candidate.path
        scanned_font_count += 1
        if candidate.supports_cjk:
            cjk_ready_count += 1
        try:
            if font_manager is not None:
                font_manager.fontManager.addfont(font_path)
                font_name = font_manager.FontProperties(fname=font_path).get_name()
            else:
                font_name = ""
        except Exception:
            continue
        if font_name and font_name not in resolved_names:
            resolved_names.append(font_name)
        if candidate.supports_cjk and font_name and not selected_font_name:
            selected_font_name = font_name
            selected_font_path = font_path

    # 没找到“验证通过”的中文字体时，降级使用第一个成功注册字体。
    if not selected_font_name and resolved_names:
        selected_font_name = resolved_names[0]

    # 若未找到可注册字体，则保留一组常见字体名，交给系统字体回退。
    fallback_names = [
        "Noto Sans CJK SC",
        "Noto Sans CJK",
        "Source Han Sans CN",
        "Droid Sans Fallback",
        "sans-serif",
    ]
    final_names = resolved_names + [name for name in fallback_names if name not in resolved_names]
    try:
        # 关键：优先把 family 指向具体字体名，避免落到 DejaVu Sans 这类无中文字形字体。
        if selected_font_name:
            matplotlib.rcParams["font.family"] = [selected_font_name]
        else:
            matplotlib.rcParams["font.family"] = ["sans-serif"]
        matplotlib.rcParams["font.sans-serif"] = final_names
        matplotlib.rcParams["axes.unicode_minus"] = False
    except Exception as error:
        return f"matplotlib font setup failed: {error}"
    if selected_font_name:
        return (
            f"matplotlib font ready: name={selected_font_name}, path={selected_font_path}, "
            f"scanned={scanned_font_count}, cjkReady={cjk_ready_count}, loaded={len(resolved_names)}"
        )
    return (
        "matplotlib font fallback ready "
        f"(scanned={scanned_font_count}, cjkReady={cjk_ready_count}, loaded={len(resolved_names)})"
    )


def _normalize_chart_files(raw_files: Any) -> List[str]:
    """将 `_chart_files` 统一规范成字符串路径列表。"""
    if not isinstance(raw_files, list):
        return []
    result: List[str] = []
    for item in raw_files:
        path = str(item).strip()
        if not path:
            continue
        result.append(path)
    return result


def _runtime_root_from_output_dir(output_dir: str) -> str:
    """根据 output_dir 推导插件运行目录根（用于约束绝对路径写入范围）。"""
    # output_dir 形如: <runtime_root>/chart_outputs/run_xxx
    return os.path.abspath(os.path.join(output_dir, os.pardir, os.pardir))


def _resolve_and_ensure_output_path(path_value: Any, output_dir: str) -> str:
    """规范化保存路径并确保父目录存在。

    规则:
    1. 相对路径统一落到 output_dir。
    2. 绝对路径只允许写入插件 runtime 根目录内部，防止越界写入。
    3. 对最终路径的父目录执行 mkdir -p。
    """
    raw = os.fspath(path_value)
    if not isinstance(raw, str):
        raw = str(raw)
    if not raw.strip():
        raise ValueError("empty output path")

    # 相对路径统一转换到本次执行输出目录，避免写到不可控位置。
    if os.path.isabs(raw):
        target = os.path.abspath(raw)
    else:
        target = os.path.abspath(os.path.join(output_dir, raw))

    runtime_root = _runtime_root_from_output_dir(output_dir)
    # 仅允许落在插件 runtime 目录内，防止越界写入系统路径。
    if os.path.commonpath([target, runtime_root]) != runtime_root:
        raise ValueError(
            f"invalid output path (outside runtime sandbox): {target}"
        )

    parent = os.path.dirname(target)
    if parent:
        os.makedirs(parent, exist_ok=True)
    return target


def _patch_save_targets(output_dir: str, plt: Any) -> List[Tuple[Any, str, Any]]:
    """给常见图像保存入口加路径兜底，返回补丁句柄用于恢复。"""
    patched: List[Tuple[Any, str, Any]] = []

    def _patch_attr(obj: Any, name: str, wrapper_builder):
        original = getattr(obj, name, None)
        if original is None:
            return
        wrapped = wrapper_builder(original)
        setattr(obj, name, wrapped)
        patched.append((obj, name, original))

    # 兜底 matplotlib.pyplot.savefig(path)
    if plt is not None:
        def _wrap_pyplot_savefig(original):
            def _wrapped(*args, **kwargs):
                if args:
                    first = args[0]
                    if isinstance(first, (str, os.PathLike)):
                        normalized = _resolve_and_ensure_output_path(first, output_dir)
                        args = (normalized, *args[1:])
                elif "fname" in kwargs and isinstance(kwargs["fname"], (str, os.PathLike)):
                    kwargs["fname"] = _resolve_and_ensure_output_path(kwargs["fname"], output_dir)
                return original(*args, **kwargs)

            return _wrapped

        _patch_attr(plt, "savefig", _wrap_pyplot_savefig)

    # 兜底 matplotlib.figure.Figure.savefig(path)
    matplotlib_figure = _safe_import("matplotlib.figure")
    if matplotlib_figure is not None and hasattr(matplotlib_figure, "Figure"):
        def _wrap_figure_savefig(original):
            def _wrapped(self, *args, **kwargs):
                if args:
                    first = args[0]
                    if isinstance(first, (str, os.PathLike)):
                        normalized = _resolve_and_ensure_output_path(first, output_dir)
                        args = (normalized, *args[1:])
                elif "fname" in kwargs and isinstance(kwargs["fname"], (str, os.PathLike)):
                    kwargs["fname"] = _resolve_and_ensure_output_path(kwargs["fname"], output_dir)
                return original(self, *args, **kwargs)

            return _wrapped

        _patch_attr(matplotlib_figure.Figure, "savefig", _wrap_figure_savefig)

    # 兜底 PIL.Image.Image.save(path)
    pil_image = _safe_import("PIL.Image")
    if pil_image is not None and hasattr(pil_image, "Image"):
        def _wrap_pil_save(original):
            def _wrapped(self, fp, *args, **kwargs):
                if isinstance(fp, (str, os.PathLike)):
                    fp = _resolve_and_ensure_output_path(fp, output_dir)
                return original(self, fp, *args, **kwargs)

            return _wrapped

        _patch_attr(pil_image.Image, "save", _wrap_pil_save)

    return patched


def _restore_patched_methods(patched: List[Tuple[Any, str, Any]]) -> None:
    """恢复被 patch 的方法，避免影响后续执行上下文。"""
    for obj, name, original in reversed(patched):
        try:
            setattr(obj, name, original)
        except Exception:
            continue


def _build_output_dir() -> str:
    """为当前执行自动生成独立输出目录。"""
    run_id = uuid.uuid4().hex[:12]
    output_dir = os.path.join(os.getcwd(), "chart_outputs", f"run_{run_id}")
    os.makedirs(output_dir, exist_ok=True)
    return output_dir


def _collect_generated_files(
    output_dir: str,
    before_files: List[str],
    declared_files: List[str],
) -> List[str]:
    """汇总本次生成图表文件。

    优先使用用户声明的 `_chart_files`，并补充输出目录中新产生的文件。
    """
    result: List[str] = []
    seen = set()

    # 先收集脚本主动声明的图表路径。
    for path in declared_files:
        normalized = os.path.abspath(path)
        if normalized in seen:
            continue
        seen.add(normalized)
        result.append(normalized)

    # 再补充输出目录中新增的文件（递归），防止用户忘记写 `_chart_files`。
    current_files: List[str] = []
    try:
        for root, _, files in os.walk(output_dir):
            for name in files:
                full_path = os.path.abspath(os.path.join(root, name))
                if os.path.isfile(full_path):
                    current_files.append(full_path)
    except Exception:
        current_files = []
    before_set = {os.path.abspath(item) for item in before_files}
    for full_path in sorted(current_files):
        if full_path in before_set or full_path in seen:
            continue
        seen.add(full_path)
        result.append(full_path)
    return result


def _auto_save_open_figures(output_dir: str) -> List[str]:
    """当模型忘记 savefig 时，自动将当前打开的 figure 导出到输出目录。"""
    matplotlib = _safe_import("matplotlib")
    if matplotlib is None:
        return []
    try:
        pyplot = __import__("matplotlib.pyplot", fromlist=["pyplot"])
        helpers = __import__("matplotlib._pylab_helpers", fromlist=["Gcf"])
    except Exception:
        return []

    saved_files: List[str] = []
    managers = list(getattr(helpers.Gcf, "get_all_fig_managers", lambda: [])() or [])
    for index, manager in enumerate(managers, start=1):
        figure = getattr(manager, "canvas", None)
        figure = getattr(figure, "figure", None)
        if figure is None:
            continue
        file_path = os.path.abspath(os.path.join(output_dir, f"auto_chart_{index}.png"))
        try:
            figure.savefig(file_path, dpi=150, bbox_inches="tight")
            saved_files.append(file_path)
        except Exception:
            continue
    try:
        pyplot.close("all")
    except Exception:
        pass
    return saved_files


def main(payload: Dict[str, Any]) -> Dict[str, Any]:
    """工具入口。

    输入:
        payload["code"]: 要执行的 Python 代码（必填）
    """
    code = str(payload.get("code", "") or "")
    if not code.strip():
        return {
            "ok": False,
            "summary": "python_chart_exec 缺少 code 参数",
            "error": "missing code",
            "stdout": "",
            "stderr": "",
            "chartFiles": [],
            "libraries": _detect_chart_libraries(),
        }

    # 不从入参读取输出目录，始终由工具自动生成本次执行专属目录。
    output_dir = _build_output_dir()
    before_files: List[str] = []
    try:
        for root, _, files in os.walk(output_dir):
            for name in files:
                full_path = os.path.abspath(os.path.join(root, name))
                if os.path.isfile(full_path):
                    before_files.append(full_path)
    except Exception:
        before_files = []

    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()

    # 默认注入常见图表变量，降低模型编写代码门槛。
    np = _safe_import("numpy")
    pd = _safe_import("pandas")
    sns = _safe_import("seaborn")
    plotly = _safe_import("plotly")

    plt = None
    font_setup_message = "matplotlib: missing"
    matplotlib = _safe_import("matplotlib")
    if matplotlib is not None:
        try:
            font_setup_message = _setup_matplotlib_chinese()
            plt = __import__("matplotlib.pyplot", fromlist=["pyplot"])
        except Exception:
            plt = None

    exec_scope: Dict[str, Any] = {
        "__name__": "__main__",
        "__builtins__": __builtins__,
        "np": np,
        "pd": pd,
        "plt": plt,
        "sns": sns,
        "plotly": plotly,
        "output_dir": output_dir,
        # 供模型显式获取安全输出路径使用。
        "ensure_output_path": lambda path: _resolve_and_ensure_output_path(path, output_dir),
        # 供模型一行保存图像使用（内部会自动创建父目录）。
        "savefig_safe": (
            (lambda path, **kwargs: plt.savefig(_resolve_and_ensure_output_path(path, output_dir), **kwargs))
            if plt is not None
            else None
        ),
        "_result": None,
        "_chart_files": [],
    }

    exit_code = 0
    previous_cwd = os.getcwd()
    patched_methods: List[Tuple[Any, str, Any]] = []
    try:
        # 将 cwd 暂时切到 output_dir，保证相对路径保存的图片都落在输出目录下。
        os.chdir(output_dir)
        # 在执行用户代码前对保存入口做兜底，处理“目录不存在”的高频错误。
        patched_methods = _patch_save_targets(output_dir=output_dir, plt=plt)
        with contextlib.redirect_stdout(stdout_buffer), contextlib.redirect_stderr(
            stderr_buffer
        ):
            exec(compile(code, "<python_chart_exec>", "exec"), exec_scope, exec_scope)
    except Exception:
        exit_code = 1
        traceback.print_exc(file=stderr_buffer)
    finally:
        _restore_patched_methods(patched_methods)
        try:
            os.chdir(previous_cwd)
        except Exception:
            pass
        # 避免 matplotlib 句柄持续堆积。
        if plt is not None:
            try:
                plt.close("all")
            except Exception:
                pass

    stdout_text = stdout_buffer.getvalue()
    stderr_text = stderr_buffer.getvalue()
    declared_chart_files = _normalize_chart_files(exec_scope.get("_chart_files"))
    chart_files = _collect_generated_files(
        output_dir=output_dir,
        before_files=before_files,
        declared_files=declared_chart_files,
    )
    # 若模型未显式保存文件，自动兜底导出当前 figure。
    if not chart_files:
        auto_saved = _auto_save_open_figures(output_dir)
        if auto_saved:
            chart_files = _collect_generated_files(
                output_dir=output_dir,
                before_files=before_files,
                declared_files=auto_saved,
            )
    result_value = exec_scope.get("_result")
    libraries = _detect_chart_libraries()

    ok = exit_code == 0
    error_line = None
    if not ok:
        error_line = stderr_text.strip().splitlines()[0] if stderr_text.strip() else "execution_failed"
    error_type = None
    if not ok:
        lowered = stderr_text.lower()
        if "filenotfounderror" in lowered or "no such file or directory" in lowered:
            error_type = "path_not_found"
        elif "permissionerror" in lowered or "read-only file system" in lowered:
            error_type = "permission_denied"
        elif "outside runtime sandbox" in lowered:
            error_type = "invalid_output_path"
        else:
            error_type = "execution_error"

    summary = (
        f"python_chart_exec 执行成功，chart_files={len(chart_files)}"
        if ok
        else f"python_chart_exec 执行失败({error_type})"
    )
    return {
        "ok": ok,
        "summary": summary,
        "error": None if ok else error_line,
        "errorType": error_type,
        "stdout": stdout_text,
        "stderr": stderr_text,
        "result": result_value,
        "chartFiles": chart_files,
        "generatedChartFiles": chart_files,
        "libraries": libraries,
        "outputDir": output_dir,
        "fontSetup": font_setup_message,
    }
